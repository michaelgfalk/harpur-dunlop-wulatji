# Land and Language in Colonial Australian Romanticism

Manuscript files for my work-in-progress article on Charles Harpur, Eliza Hamilton Dunlop, the Awabakal poet Wulatji, and the poetics of language in colonial Australian verse.

(c) Michael Falk, 2024

## Licence

**Code:** [MIT License](https://mit-license.org/)

**Prose and Data:** The prose of the manuscript and the files in [data](data) are available under the [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/deed.en) license.
